package panyujie.practice.work1.one;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: Submerge
 * Date: 2022-02-17
 * Time: 13:12
 * @author Submerge
 */

public class Test {
    public static void main(String[] args){
        System.out.println("Hello World");
    }
}
